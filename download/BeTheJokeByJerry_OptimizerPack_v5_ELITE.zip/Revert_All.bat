
@echo off
echo Reverting...
bcdedit /deletevalue disabledynamictick
bcdedit /deletevalue useplatformclock
netsh int tcp set global autotuninglevel=normal
echo Reverted. Reboot required.
pause
