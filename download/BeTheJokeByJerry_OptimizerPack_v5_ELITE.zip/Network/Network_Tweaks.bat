
@echo off
netsh int tcp set global autotuninglevel=disabled
netsh int tcp set global rss=enabled
netsh int tcp set global chimney=enabled
netsh int tcp set global ecncapability=disabled
netsh int tcp set global timestamps=disabled
echo Consider MTU tuning in guide.
pause
