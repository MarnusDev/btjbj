
BeTheJokeByJerry ELITE v5 (Robin Hood Pack)

GOAL:
- Lowest input lag possible
- Best hit registration
- Lowest packet loss

FLOW:
1. Run Apply_All.bat (Admin)
2. Reboot
3. Follow INPUT + GPU + COD folders
4. Test in-game

IMPORTANT:
This pack includes advanced tweaks. Apply only what you understand.
