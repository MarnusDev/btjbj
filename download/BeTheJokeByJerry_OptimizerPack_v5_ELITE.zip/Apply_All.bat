
@echo off
echo Applying ELITE tweaks...
call System/Core_Tweaks.bat
call System/Memory_Tweaks.bat
call Network/Network_Tweaks.bat
echo Done. Reboot required.
pause
